jQuery(function($){
	$(document).ready(function(){
		$('.calluna-shortcodes-lightbox').magnificPopup({
			type: 'image',
			gallery: { enabled: false }
		});
	});
});